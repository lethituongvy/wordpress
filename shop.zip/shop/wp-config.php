<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'shopbanhang' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'g7/O&OCdxQ?yu9s$0DN/t|!U9w9[SNVawx}B#:5>a>/X#f7iN/ZdX~6CoD&EFcd#' );
define( 'SECURE_AUTH_KEY',  '<f;~1*9N;YIw9zc6C|g_Yo}*%B-$RMK9tE,n%=3v-z)(@^{oi3SoaD:?i]7iL7<K' );
define( 'LOGGED_IN_KEY',    '5FeVz>WA4vfc&dA3}]$)<S3WIkvvK,nVuW/:PB!J`O)$bBo],:l,EW~e*D1M|Z(V' );
define( 'NONCE_KEY',        '*=8)8?+Ob!6t*igi|bj!.hMo!u][|fH_2D5D<$2TM`+2gB9tq[ct8d#C%|i:0,[&' );
define( 'AUTH_SALT',        'J.L^Etq1L?^obknOiO)`)*bhNlI;u4(b^(4b`&@!NBU_eA`CTtT!eG4H?Em,a8w5' );
define( 'SECURE_AUTH_SALT', 'AJNlBj$%6&hfijVD(XtJMTy*pFXMoK<T|Vpv<a4`hcwXM4@QE[S,H/v]7pbzhVGV' );
define( 'LOGGED_IN_SALT',   'PXgk[LUj6o{h>^9%Wi<c+ E/0iAgQbGhN$(}w^urwY9sbkPb+(rH#R~7iowg#e8$' );
define( 'NONCE_SALT',       '4P$BoeU1vE~a-|FR#/i&okxx/$-PtfX7pL`.s:;/EZa29sJoG83y%BWH9QEvd yW' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
